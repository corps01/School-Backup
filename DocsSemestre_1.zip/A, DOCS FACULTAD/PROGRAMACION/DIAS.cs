﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            int dia;
            Console.WriteLine("SELECCIONE UN DIA DE LA SEMANA\n(1)DOMINGO\n(2)LUNES\n(3)MARTES\n(4)MIERCOLES\n(5)JUEVES\n(6)VIERNES\n(7)SABADO");
            dia = int.Parse(Console.ReadLine());

            switch (dia) { 
                case 1:
                    Console.WriteLine("EL DIA ES DOMINGO");
                    break;
                case 2:
                    Console.WriteLine("EL DIA ES LUNES");
                    break;
                case 3:
                    Console.WriteLine("EL DIA ES MARTES");
                    break;
                case 4:
                    Console.WriteLine("EL DIA ES MIERCOLES");
                    break;
                case 5:
                    Console.WriteLine("EL DIA ES JUEVES");
                    break;
                case 6:
                    Console.WriteLine("EL DIA ES VIERNES");
                    break;
                case 7:
                    Console.WriteLine("EL DIA ES SABADO");
                    break;
                default:
                    Console.WriteLine("NO ES UN NUMERO DE LA SEMANA JIJIJIJ xdxdddxdxxdddd");
                    break;


            }



            Console.ReadLine();
        }
    }
}
