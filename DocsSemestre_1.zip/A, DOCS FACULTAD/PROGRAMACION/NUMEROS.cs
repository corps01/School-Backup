﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            int num1, num2;
            string numero1 = "", numero2= "";

            Console.WriteLine("INGRESE EL PRIMER NUMERO ");
            num1 = int.Parse(Console.ReadLine());

            Console.WriteLine("INGRESE EL SEGUNDO NUMERO ");
            num2 = int.Parse(Console.ReadLine());

            switch (num1)
            {

                case 0:
                    numero1 = "";
                    break; 
                case 1:
                    numero1 = "";
                    break;
                case 2:
                    numero1 = "VEINTE";
                    break;
                case 3:
                    numero1 = "TREINTA";
                    break;
                case 4:
                    numero1 = "CUARENTA";
                    break;
                case 5:
                    numero1 = "CINCUENTA";
                    break;
                case 6:
                    numero1 = "SESENTA";
                    break;
                case 7:
                    numero1 = "SETENTA";
                    break;
                case 8:
                    numero1 = "OCHENTA";
                    break;
                case 9:
                    numero1 = "NOVENTA";
                    break;
                default:
                    Console.WriteLine("NO ES UNA OPCION ");
                    break;
            }

            switch (num2)
            {

                case 0:
                    numero2 = "";
                    break;
                case 1:
                    numero2 = " y UNO";
                    break;
                case 2:
                    numero2 = " y DOS";
                    break;
                case 3:
                    numero2 = " y TRES";
                    break;
                case 4:
                    numero2 = " y CUATRO";
                    break;
                case 5:
                    numero2 = " y CINCO";
                    break;
                case 6:
                    numero2 = " y SEIS";
                    break;
                case 7:
                    numero2 = " y SIETE";
                    break;
                case 8:
                    numero2 = " y OCHO";
                    break;
                case 9:
                    numero2 = " y NUEVE";
                    break;
                default:
                    Console.WriteLine("NO ES UNA OPCION ");
                    break;
            }

            if (num1 == 1 && num2 == 0)
            {
                numero1 = "DIEZ";
                numero2 = "";
            }
            else {
                if (num1 == 1) { 
                switch (num2) { 
                    case 1:
                        numero1 = "ONCE";
                        numero2 = "";
                    break;
                    case 2:
                    numero1 = "DOCE";
                    numero2 = "";
                    break;
                    case 3:
                    numero1 = "TRECE";
                    numero2 = "";
                    break;
                    case 4:
                    numero1 = "CATORCE";
                    numero2 = "";
                    break;
                    case 5:
                    numero1 = "QUINCE";
                    numero2 = "";
                    break;
                }
                }
            }

          


            Console.WriteLine("SU NUMERO ES: " +numero1+numero2 );
            Console.ReadLine();
        }
    }
}
