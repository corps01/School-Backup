﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            Random rnd = new Random();
            double[,] calAlumnos = new double[5, 5];
            string[] alumnos = new string[5];

           for (int i = 0; i < 5; i++) { 
                Console.WriteLine("INTRODUZCA EL NOMBRE DEL ALUMNO NUMERO " + (i+1) );
                alumnos[i] = Console.ReadLine();

            } 

            //GENERAR CALIFICACIONES
           Console.WriteLine("\n");
            for (int i = 0; i < 5; i++) {
                for (int y = 0; y < 4; y++) {
                    calAlumnos[i,y] = rnd.Next(5, 10);         
                }
                calAlumnos[i,4] = (calAlumnos[i,0] + calAlumnos[i,1] + calAlumnos[i,2] + calAlumnos[i,3])/4;
            }

            for (int i = 0; i <= 4; i++)
            {
                Console.WriteLine("~ALUMNO: " + alumnos[i]);
                Console.WriteLine("MATERIA 1" +" | "+ calAlumnos[i,0]);
                Console.WriteLine("MATERIA 2"+ " | "+calAlumnos[i, 1]);
                Console.WriteLine("MATERIA 3"+" | "+ calAlumnos[i, 2]);
                Console.WriteLine("MATERIA 4" + " | " + calAlumnos[i, 3]);
                Console.WriteLine("PROMEDIO:" + " | " + calAlumnos[i, 4]);
                Console.WriteLine("\n");
            }

            //IMPRIMIR TABLA
            for (int i = 0; i <= 4; i++)
            {
                for (int y = 0; y <= 4; y++)
                {
                    Console.Write(calAlumnos[i, y] + " ");
                }
                Console.Write("\n");
            }


                Console.ReadLine();
        }
    }
}
