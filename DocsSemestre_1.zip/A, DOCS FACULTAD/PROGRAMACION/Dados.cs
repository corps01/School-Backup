﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            Random rnd = new Random();
            int i, suma, ganador=0, temp=0;
            int[] jugadores = new int[5];

            Console.OutputEncoding = System.Text.Encoding.Unicode;
            Console.WriteLine("\\\\\\\\ ☺ BIENVENIDO AL JUEGO DE DADOS ☺  \\\\\\\\ \nPRESIONE UNA TECLA PARA CONTINUAR ");
            Console.ReadLine();

            //JUGADORES
            for(i = 0; i<=4; i++){
            int dado = rnd.Next(1, 7);
            int dado2 = rnd.Next(1, 7);
            suma = dado + dado2;
            jugadores[i] = suma;

            Console.WriteLine("JUGADOR " + (i+1) + "\nDado1: " + dado + "\nDado2: " + dado2 + "\nSUMA: " + suma);
            Console.WriteLine("PRESIONE UNA TECLA PARA CONTINUAR ");
            Console.ReadLine();
            }

            Console.WriteLine(" ~ RESULTADOS ~");
            for (i = 0; i <= 4; ++i)
            {
                Console.WriteLine("Participante " + (i+1) + ": " + jugadores[i]);

                if (jugadores[i] > temp)
                {
                    temp = jugadores[i];
                    ganador = (i+1);
                }
            }

            Console.WriteLine("\n EL GANADOR ES EL JUGADOR " + ganador + "!");
            Console.ReadLine();
            }
        }
    }
