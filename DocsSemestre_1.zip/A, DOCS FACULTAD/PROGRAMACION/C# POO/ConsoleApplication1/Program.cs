﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            //DECLARAR VARIABLES
            Random rnd = new Random();
            int menu = 0, i, y ,cont = 0;
            double temp;
            double[,] cilindros = new double[5,10];
            double[] cilindrosSuma = new double[50];
            Console.WriteLine("EXAMEN PARCIAL 2 ~CILINDROS~");
            

            //CICLO
            do{

            //MENU
                Console.WriteLine("INGRESE UNA OPCION:");
                Console.WriteLine("1) Llenado de Matriz, \n2) Modificar Radio, Altura o ambas");
                Console.WriteLine("3) Modificar radio de un cilindro, \n4) Sumatorias de cada columna de la matriz.");
                Console.WriteLine("5) cilindro de menor volumen. \n6) SALIR");
                menu = int.Parse(Console.ReadLine());
                switch (menu) { 
                    case 1:

                        //lleno de matriz
                        for (y = 0; y < 10; y++) {
                            //radio
                            cilindros[0, y] = rnd.Next(1,6);
                            //altura
                            cilindros[1, y] = rnd.Next(1, 10);

                            //area base
                            cilindros[2, y] = 3.14 * (cilindros[0, y] * cilindros[0, y]);

                            //area lateral
                            cilindros[3, y] = 2 * 3.14 * cilindros[0, y] * cilindros[1, y];

                            //volumen del cilindro
                            cilindros[4, y] = 3.14 * (cilindros[0, y] * cilindros[0, y]) * cilindros[1, y];

                        }


                        //imprimir

                        for (y = 0; y < 10; y++ ) {
                            for (i = 0; i < 5; i++) {
                                Console.Write(cilindros[i,y] + " | ");
                            }
                            Console.WriteLine("");
                        }


                        Console.WriteLine("\n\n");
                            break;
                    case 2:

                        //modificar radio, altura o las 2
                            Console.WriteLine("QUE DESEA MODIFICAR? 1) RADIO 2) ALTURA 3) RADIO, ALTURA");
                            menu = int.Parse(Console.ReadLine());

                            switch (menu) { 
                                case 1:
                                    Console.WriteLine("CAMBIAR RADIO");
                                    for (y = 0; y < 10; y++)
                                    {
                                        //radio
                                        cilindros[0, y] = rnd.Next(1, 6);

                                        //calcular

                                        //area base
                                        cilindros[2, y] = 3.14 * (cilindros[0, y] * cilindros[0, y]);

                                        //area lateral
                                        cilindros[3, y] = 2 * 3.14 * cilindros[0, y] * cilindros[1, y];

                                        //volumen del cilindro
                                        cilindros[4, y] = 3.14 * (cilindros[0, y] * cilindros[0, y]) * cilindros[1, y];

                                    }

                                    //imprimir

                                    for (y = 0; y < 10; y++)
                                    {
                                        for (i = 0; i < 5; i++)
                                        {
                                            Console.Write(cilindros[i, y] + " | ");
                                        }
                                        Console.WriteLine("");
                                    }

                                    Console.WriteLine("\n\n");
                                    break;
                                case 2:

                                    Console.WriteLine("CAMBIAR ALTURA");
                                    for (y = 0; y < 10; y++)
                                    {
                                        //altura
                                        cilindros[1, y] = rnd.Next(1, 10);

                                        //calcular

                                        //area base
                                        cilindros[2, y] = 3.14 * (cilindros[0, y] * cilindros[0, y]);

                                        //area lateral
                                        cilindros[3, y] = 2 * 3.14 * cilindros[0, y] * cilindros[1, y];

                                        //volumen del cilindro
                                        cilindros[4, y] = 3.14 * (cilindros[0, y] * cilindros[0, y]) * cilindros[1, y];

                                    }
                                    //imprimir

                                    for (y = 0; y < 10; y++)
                                    {
                                        for (i = 0; i < 5; i++)
                                        {
                                            Console.Write(cilindros[i, y] + " | ");
                                        }
                                        Console.WriteLine("");
                                    }

                                    Console.WriteLine("\n\n");
                                    break;
                                case 3:
                                      Console.WriteLine("CAMBIAR RADIO, ALTURA");
                                    for (y = 0; y < 10; y++)
                                    {
                                        //radio
                                        cilindros[0, y] = rnd.Next(1, 6);
                                        //altura
                                        cilindros[1, y] = rnd.Next(1, 10);

                                        //calcular

                                        //area base
                                        cilindros[2, y] = 3.14 * (cilindros[0, y] * cilindros[0, y]);

                                        //area lateral
                                        cilindros[3, y] = 2 * 3.14 * cilindros[0, y] * cilindros[1, y];

                                        //volumen del cilindro
                                        cilindros[4, y] = 3.14 * (cilindros[0, y] * cilindros[0, y]) * cilindros[1, y];

                                    }

                                    //imprimir

                                    for (y = 0; y < 10; y++)
                                    {
                                        for (i = 0; i < 5; i++)
                                        {
                                            Console.Write(cilindros[i, y] + " | ");
                                        }
                                        Console.WriteLine("");
                                    }

                                    Console.WriteLine("\n\n");
                                    break;
                            }
                            menu = 0;
                        break;

                    case 3:
                        //modificar un cilindro en especifico 
                        Console.WriteLine("QUE CILINDRO DESEA MODIFICAR? 0,1,2,3,4,5,6,7,8,9");
                        y = int.Parse(Console.ReadLine());

                            //radio
                            cilindros[0, y] = rnd.Next(1, 6);
                            //altura
                            cilindros[1, y] = rnd.Next(1, 10);

                            //area base
                            cilindros[2, y] = 3.14 * (cilindros[0, y] * cilindros[0, y]);

                            //area lateral
                            cilindros[3, y] = 2 * 3.14 * cilindros[0, y] * cilindros[1, y];

                            //volumen del cilindro
                            cilindros[4, y] = 3.14 * (cilindros[0, y] * cilindros[0, y]) * cilindros[1, y];

                        //imprimir
                            for (y = 0; y < 10; y++)
                            {
                                for (i = 0; i < 5; i++)
                                {
                                    Console.Write(cilindros[i, y] + " | ");
                                }
                                Console.WriteLine("");
                            }


                        Console.WriteLine("\n\n");
                        break;
                    case 4:
                        
                        //suma dentro de un vector
                        //contador de vector
                        int x = 0;

                        for (i = 0; i < 5; i++)
                        {
                            for (y = 0; y < 10; y++)
                            {
                                x++;
                                cilindrosSuma[x] = cilindrosSuma[x] + cilindros[i,y];
                            }

                            Console.WriteLine("CILINDORO:"+ i + cilindrosSuma[x]);
                        }

                        Console.WriteLine("\n\n");
                        break;
                    case 5:
                        //idicar menor volumen 

                        temp = cilindros[4, 0];
                            for (y = 0; y < 10; y++)
                            {

                                if (temp > cilindros[4, y]) {
                                    temp = cilindros[4, y];
                                    cont = y;
                                }
                            }

                            Console.WriteLine("EL CILINDRO CON MENOR VOLUMEN ES EL CILINDRO: "+ cont + " DE VOLUMEN: "+ temp);

                        Console.WriteLine("\n\n");
                        break;
                    case 6:
                        Console.WriteLine("PRESIONE ENTER PARA SALIR...");
                        Console.ReadLine();
                        break;

                }

            }while (menu != 6);
           

        }
    }
}
