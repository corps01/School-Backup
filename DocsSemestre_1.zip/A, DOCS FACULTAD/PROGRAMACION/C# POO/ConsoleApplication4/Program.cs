﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)

        {

            int p1, p2;

            Console.WriteLine("/// F R U T A S  -  M U T A N T E S///\nPresione enter despues de cada linea para generar otra Fruta Mutante\n\n");
          
            //declarar objetos
            monsters[] mutante = new monsters[10];
            arena[] batallas = new arena[5];
            int[] Battle = new int[5];
            
            for (int i = 0; i < 10; i++) {
                mutante[i] = new monsters();

                mutante[i].id = (i + 1);
                mutante[i].name = mutante[i].getName();
                mutante[i].age = mutante[i].getAge();
                mutante[i].race = mutante[i].getRace();
                mutante[i].health = mutante[i].getHealth();
                mutante[i].attack = mutante[i].getAttack();

                Console.WriteLine("ID: " + mutante[i].id);
                Console.WriteLine("NOMBRE: " + mutante[i].name);
                Console.WriteLine("EDAD: " + mutante[i].age);
                Console.WriteLine("RAZA: " + mutante[i].race);
                Console.WriteLine("VIDA: " + mutante[i].health);
                Console.WriteLine("ATAQUE: " + mutante[i].attack);
                Console.WriteLine("___________________________");
                Console.ReadLine();

            }

            //LUCHAS

            for (var i = 0; i < Battle.Length; i++)
            {

                batallas[i] = new arena();

                Console.WriteLine("ELIJA EL JUGADOR 1");
                batallas[i].p1 = int.Parse(Console.ReadLine());

                Console.WriteLine("ELIJA EL JUGAR 2");
                batallas[i].p2 = int.Parse(Console.ReadLine());


                Console.WriteLine("\n* * * B A T A L L A * * *");
                Console.WriteLine("ID: " + mutante[batallas[i].p1 -1].id);
                Console.WriteLine("NOMBRE: " + mutante[batallas[i].p1 - 1].name);
                Console.WriteLine("EDAD: " + mutante[batallas[i].p1 - 1].age);
                Console.WriteLine("RAZA: " + mutante[batallas[i].p1 - 1].race);
                Console.WriteLine("VIDA: " + mutante[batallas[i].p1 - 1].health);
                Console.WriteLine("ATAQUE: " + mutante[batallas[i].p1 - 1].attack);

                Console.WriteLine("\n V S \n");
                Console.WriteLine("ID: " + mutante[batallas[i].p2 - 1].id);
                Console.WriteLine("NOMBRE: " + mutante[batallas[i].p2 - 1].name);
                Console.WriteLine("EDAD: " + mutante[batallas[i].p2 - 1].age);
                Console.WriteLine("RAZA: " + mutante[batallas[i].p2 - 1].race);
                Console.WriteLine("VIDA: " + mutante[batallas[i].p2 - 1].health);
                Console.WriteLine("ATAQUE: " + mutante[batallas[i].p2 - 1].attack);

                int winner = batallas[i].Fight(mutante);

                Console.WriteLine("\n//////// EL GANADOR ES: "  + winner + " ////////");




            }


            Console.ReadLine();

        }
    }
}
