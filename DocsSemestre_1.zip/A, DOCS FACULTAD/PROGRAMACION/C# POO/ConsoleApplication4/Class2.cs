﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class arena
    {

        //Atributos
        public int winner;
        public int p1, p2;

        public arena() {

        }


        //METODOS

        public int Fight(monsters[] cadena) { 
        
            int player1 = cadena[p1 - 1].health - cadena[p2 -1].attack;
            int player2 = cadena[p2 - 1].health - cadena[p1 -1].attack;

            if(player1 > player2){
                    winner = p1;
            
            } else {
                winner = p2;
                    }
            return winner;
        }





    }
}
