﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class monsters
    {
        //Atributos
        public int id;
        public string name;
        public string race;
        public int age;
        public int health;
        public int attack;

        //Constructor
        public monsters(){
        name = "Sin nombre";
        race = "Sin raza";
        id = 0;
        age = 0;
        health = 0;
        attack = 0;
        
        }

       ///M E T O D O S///


        //Edad
        public int getAge(){
        Random rndEdad = new Random();
        int age = rndEdad.Next(1, 98);

            return age;
        }
        //Nombre
        public string getName() {
            Random rnd = new Random();
            int temp = rnd.Next(1, 6);
            switch (temp) { 
                case 1:
                    name = "Fresamon";
                    break;
                case 2:
                    name = "Naranjamon";
                    break;
                case 3:
                    name = "Zandiamon";
                    break;
                case 4:
                    name = "Limomon";
                    break;
                case 5:
                    name = "Uvamon";
                    break;
                case 6:
                    name = "Mangomon";
                    break;       
            }
            return name;
        }

        public string getRace() {
            Random rnd = new Random();
            int temp = rnd.Next(1, 6);
            switch (temp) { 
                case 1:
                    race = "Mora";
                    break;
                case 2:
                    race = "Citrico";
                    break;
                case 3:
                    race = "Melon";
                    break;
                case 4:
                    race = "Fruto_Arbol";
                    break;
                case 5:
                    race = "Fruto_Arbusto";
                    break;
                case 6:
                    race = "No_Mutante";
                    break;       
            }
            return race;
        }

        //Vida
        public int getHealth()
        {
            Random rndHealth = new Random();
            int health = rndHealth.Next(1, 102);

            return health;
        }

        //Ataque
        public int getAttack()
        {
            Random rndAttack = new Random();
            int attack = rndAttack.Next(1, 103);

            return attack;
        }


    }


}
