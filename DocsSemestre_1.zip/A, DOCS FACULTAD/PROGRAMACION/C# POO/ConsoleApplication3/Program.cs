﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication2
{
    class Program
    {
        static void Main(string[] args)
        {
            ClassTarjetas tarjeta = new ClassTarjetas();
            int op1;

            do
            {
                Console.WriteLine("$$$$$$$ CAJERO AUTOMATICO $$$$$$$");
                Console.WriteLine("Selecciona una opcion: \n1.- Asignar Tarjeta \n2.- Retiro Efectivo \n3.- Deposito \n4.- Consultar Saldo \n5.- Consulta de Movimientos \n6.- Salir");
                op1 = int.Parse(Console.ReadLine());

                switch (op1)
                {
                    case 1:
                        tarjeta.NuevaTarjeta();
                        break;

                    case 2:

                        tarjeta.Retirar();
                        break;

                    case 3:

                        tarjeta.Depositar();
                        break;

                    case 4:

                        tarjeta.ConsultSaldo();
                        break;

                    case 5:

                        tarjeta.movimientos();
                        break;

                    case 6:
                        Console.WriteLine("BYE ;)");
                        break;

                    default:

                        break;
                }
                Console.WriteLine("\n\n");
            } while (op1 != 6);


        }
    }
}
