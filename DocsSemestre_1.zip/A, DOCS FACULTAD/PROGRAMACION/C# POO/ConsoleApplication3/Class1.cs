﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication2
{
    class ClassTarjetas
    {
        //Atributos
        public Random tarjetarnd = new Random();
        public float Saldo;
        public string NumeroTarjeta;
        public string Movimientos;
        public string NombrePropietario;
        public string NIP;
       
        //Constructor
        public ClassTarjetas()
        {
            NIP = null;
            NumeroTarjeta = null;
            Movimientos = null;
            NombrePropietario = null;
            NumeroTarjeta = null;
            Saldo = 5000;
            Movimientos = null;
        }


        //Metodos

        public void NuevaTarjeta()
        {

            Console.WriteLine("Ingresa el nombre del propietario");
            NombrePropietario = Console.ReadLine();
            NumeroTarjeta = string.Concat(tarjetarnd.Next(1111, 9999)) + string.Concat(tarjetarnd.Next(1111, 9999));
            Console.WriteLine("INGRESE 4 NUMEROS PARA LA SU NIP");
            NIP = Console.ReadLine();

            Console.WriteLine("\n~DATOS SOBRE LA TARJETA~");
            Console.WriteLine("NOMBRE: " + NombrePropietario);
            Console.WriteLine("NUMERO DE TARJETA: " + NumeroTarjeta);
            Console.WriteLine("NIP: " + NIP);

                
        }


        public void Retirar()
        {
            Console.WriteLine("Ingresa el monto a retirar");
            int retiro = int.Parse(Console.ReadLine());
            Saldo = Saldo - retiro;
            Console.WriteLine("Su nuevo saldo es de: " + Saldo + "$");
            Movimientos = Movimientos + "\nRetiro de: " + retiro + "\nSaldo: " + Saldo;
        }

        public void Depositar()
        {
            Console.WriteLine("Ingresa el monto a depositar");
            int deposito = int.Parse(Console.ReadLine());
            Saldo = Saldo + deposito;
            Console.WriteLine("Su nuevo saldo es de: " + Saldo + "$");
            Movimientos = Movimientos + "\nDeposito de: " + deposito + "\nSaldo: " + Saldo;
        }

        public void ConsultSaldo()
        {
            Console.WriteLine("NOMBRE: " + NombrePropietario);
            Console.WriteLine("NUMERO DE TARJETA: " + NumeroTarjeta);
            Console.WriteLine("NIP: " + NIP);
            Console.WriteLine("Tu saldo disponible es de: " + Saldo + "$");

        }

        public void movimientos()
        {
            Console.WriteLine(Movimientos);

        }


    }
}
