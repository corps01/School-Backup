﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp29
{
    class ClassTarjetas
    {
        //Atributos

        public Random tarjetarnd = new Random();
        public int NIP;
        public float Saldo;
        public string NumeroTarjeta, Movimientos, NombrePropietario;

        //Constructor
        public ClassTarjetas()
        {
            
            NombrePropietario = null;
            NIP = null;
            NumeroTarjeta = null;
            Saldo = 5000;
            Movimientos = null;
        }


        //Metodos

        public void NuevaTarjeta() {

            Console.WriteLine("Ingresa el nombre del propietario");
            NombrePropietario = Console.ReadLine();
            NumeroTarjeta = string.Parse(tarjetarnd.Next(1111, 9999)) + string.Parse(tarjetarnd.Next(1111, 9999));
            Console.WriteLine("INGRESE 4 NUMEROS PARA LA SU NIP");
            NIP = Console.ReadLine();
            
        

        }


        public void Retirar()
        {
            Console.WriteLine("Ingresa el monto a retirar");
            int retiro = int.Parse(Console.ReadLine());
            Saldo = Saldo - retiro;
            Console.WriteLine("Su nuevo saldo es de: " + Saldo);
            Movimientos = Movimientos + "\nRetiro de: " + retiro + "\nSaldo: " + Saldo;
        }

        public void Depositar()
        {
            Console.WriteLine("Ingresa el monto a depositar");
            int deposito = int.Parse(Console.ReadLine());
            Saldo = Saldo + deposito;
            Console.WriteLine("Su nuevo saldo es de: " + Saldo);
            Movimientos = Movimientos + "\nDeposito de: " + deposito + "\nSaldo: " + Saldo;
        }

        public void ConsultSaldo()
        {
            Console.WriteLine("Tu saldo disponible es de: " + Saldo + "$");
            
        }

        public void movimientos()
        {
            Console.WriteLine(Movimientos);

        }


    }
}
