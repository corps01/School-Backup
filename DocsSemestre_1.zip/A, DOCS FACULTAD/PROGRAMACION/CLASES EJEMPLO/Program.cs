﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {

            Classpersona Usuario1 = new Classpersona();

            int opc;

            do{

            Console.WriteLine("EJERCICIO CLASS");
            Console.WriteLine("1.-Introducir valores para nombre y edad, \n2.-Mostrar los datos ingresados \n3.-Indicar si es mayor de edad \n4.- Salir ");
            opc = int.Parse(Console.ReadLine());
            switch (opc) {
            
                case 1:
                    Console.WriteLine("INTRODUCIR VALORES");
                    Usuario1.inicializar();
                    break;

                case 2:
                    Usuario1.imprimir();
                    break;

                case 3:
                    Usuario1.CalcularMayorEdad();
                    break;

                case 4:
                    Console.WriteLine("BYE");
                    break;
            
            }
                }while(opc != 4);

        }
    }
}
