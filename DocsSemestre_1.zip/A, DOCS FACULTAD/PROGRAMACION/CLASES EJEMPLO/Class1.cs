﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Classpersona
    {
        //ATRIBUTOS
        string nombre;
        int edad;


        //CONSTRUCTOR
        public Classpersona()
        {
            nombre = null;
            edad = 0;
        }

        //METODOS

        //MAYOR 
        public void CalcularMayorEdad(){
            if (edad > 18)
            {
                Console.WriteLine("USTED ES MAYOR DE EDAD");
            }
            else {
                Console.WriteLine("ERES MENOR DE EDAD");
            }
        
        }

        //INICIALIZAR 
        public void inicializar(){
           
        Console.WriteLine("CUAL ES TU NOMBRE?");
        nombre = Console.ReadLine();

        Console.WriteLine("CUAL ES TU EDAD?");
        edad = int.Parse(Console.ReadLine());
        }

        //IMPRIMIR
        public void imprimir(){
        Console.WriteLine(nombre + " DE "  + edad + " EDAD");
        
        }

    }
}
