﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] X = new int[100];
            int y = -1, i;
            for (i = 0; i <= 99; i = i + 2 )
            {
                y = y + 2;
                X[i] = y;
            }

            for (i = 0; i <= 99; i = i + 2)
            {
                Console.WriteLine(X[i]);
            }

            Console.ReadLine();

        }
    }
}
