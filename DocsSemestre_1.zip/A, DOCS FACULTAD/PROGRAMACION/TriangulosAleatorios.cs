﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            Random rnd = new Random();
            double temp = 0;
            int i;
            double[] hip = new double[6];

            for (i = 0; i <= 5; i++)
            {
                Console.WriteLine("\n~TRIANGULO " + (i + 1));

                double a = rnd.Next(1, 20);
                double b = rnd.Next(1, 20);

                temp = (a*a) + (b*b);
                hip[i] = Math.Sqrt(temp);

                Console.WriteLine("HIPOTENUSA: " + hip[i]);
                Console.WriteLine("BASE: " + b);
                Console.WriteLine("ALTURA: " + a);

                if (hip[i] > 1 && hip[i] < 5) { 
                    Console.WriteLine("EL TRIANGULO ES PEQUEñO\n");
                }

                if (hip[i] > 6 && hip[i] < 10)
                {
                    Console.WriteLine("EL TRIANGULO ES MEDIANO\n");
                }

                if (hip[i] >= 11)
                {
                    Console.WriteLine("EL TRIANGULO ES GRANDE\n");
                }
                
                }

            Console.ReadLine();
        }

    }
}
