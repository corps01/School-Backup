﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            int personas, noches;
            float costo = 0, descuento = 0;
            string dia;
            Console.WriteLine("( RENTA DE CABANAS )");
            Console.WriteLine("CUANTAS PERSONAS SE OSPEDAN?");
            personas = int.Parse(Console.ReadLine());

            Console.WriteLine("CUANTAS NOCHES?");
            noches = int.Parse(Console.ReadLine());

            Console.WriteLine("QUE DIA SE HOSPEDAN?");
            dia = (Console.ReadLine());


            if (personas <= 2)
            {
                costo = noches * 500;
            }
            else {
                    if (personas <= 4)
                    {
                        costo = noches * 800;
                    }
                else {
                        if(personas<= 10){
                            Console.WriteLine("SE REQUIERE MAS DE UNA CABANA");
                            costo = noches * 1000;
                         }
                    }
            }


            if (dia == "sabado" || dia == "domingo" || dia == "Sabado" || dia == "Domingo")
            {

                descuento = costo * .20f;
                costo = costo - descuento;
            }

            Console.WriteLine("TU COSTO TOTAL FUE DE: " + costo);
            Console.WriteLine("TU DESCUENTO FUE DE: "+  descuento);

            Console.ReadLine();
        }
    }
}
