﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            float moneda;
            char opc;
            Console.WriteLine("INGRESE CANTIDAD DE PESOS ");
            moneda = float.Parse(Console.ReadLine());

            Console.WriteLine("A QUE MONEDA DESEA CONVERTIR? \n(D) DOLAR\n(E) Euro\n(L) Libras");
            opc = char.Parse(Console.ReadLine());


            switch (opc) {
            
                case 'd' :
                   moneda = moneda * 0.052f;
                    break;

                case 'e':
                    moneda = moneda * 0.045f;
                    break;

                case 'l':
                    moneda = moneda * 0.040f;
                    break;
                default:
                    Console.WriteLine("NO ES UNA OPCION ");
                    break;

                    

            }
            Console.WriteLine("SU RESULTADO ES: " + moneda);
            Console.ReadLine();
        }
    }
}
